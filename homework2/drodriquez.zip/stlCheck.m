function stl = thetadot(theta, x, b)
    if yt <= l
        stl = -1;
    else
        stl = 1;
    end
end