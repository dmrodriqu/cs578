[X y] = createsepdata(2, 100);
[alpha, theta] = adaboost(10,X,y)
